To play network snake make sure you have node.js installed!
Follow the steps to set up the server:
1) open up your computers commmand prompt
2) Change your directory (cd) into the location of our game folder
3) Type 'node app.js' in command prompt. This will start up the server!
4) Go to any browser (preferably firefox or google chrome) and navigate to 'http://localhost:2000/'
	(or if connecting from a different computer, find your ip and connect to that ip address at port 2000)