var game = new Game(document.getElementById("canvas"), "gamename");


game.setup = function(){
	
}

//write game code here

game.setup();
game.start(10);